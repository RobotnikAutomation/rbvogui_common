
"use strict";

let QueryAlarm = require('./QueryAlarm.js');
let Registers = require('./Registers.js');
let ElevatorStatus = require('./ElevatorStatus.js');
let Interfaces = require('./Interfaces.js');
let SubState = require('./SubState.js');
let ElevatorAction = require('./ElevatorAction.js');
let MotorsStatusDifferential = require('./MotorsStatusDifferential.js');
let encoders = require('./encoders.js');
let MotorHeadingOffset = require('./MotorHeadingOffset.js');
let Pose2DStamped = require('./Pose2DStamped.js');
let inputs_outputs = require('./inputs_outputs.js');
let Data = require('./Data.js');
let Register = require('./Register.js');
let BatteryStatus = require('./BatteryStatus.js');
let AlarmSensor = require('./AlarmSensor.js');
let RobotnikMotorsStatus = require('./RobotnikMotorsStatus.js');
let StringArray = require('./StringArray.js');
let BatteryDockingStatus = require('./BatteryDockingStatus.js');
let named_inputs_outputs = require('./named_inputs_outputs.js');
let BatteryDockingStatusStamped = require('./BatteryDockingStatusStamped.js');
let LaserStatus = require('./LaserStatus.js');
let LaserMode = require('./LaserMode.js');
let Pose2DArray = require('./Pose2DArray.js');
let InverterStatus = require('./InverterStatus.js');
let MotorPID = require('./MotorPID.js');
let alarmsmonitor = require('./alarmsmonitor.js');
let alarmmonitor = require('./alarmmonitor.js');
let BatteryStatusStamped = require('./BatteryStatusStamped.js');
let Cartesian_Euler_pose = require('./Cartesian_Euler_pose.js');
let MotorStatus = require('./MotorStatus.js');
let ptz = require('./ptz.js');
let Alarms = require('./Alarms.js');
let State = require('./State.js');
let BoolArray = require('./BoolArray.js');
let SafetyModuleStatus = require('./SafetyModuleStatus.js');
let named_input_output = require('./named_input_output.js');
let MotorsStatus = require('./MotorsStatus.js');
let Axis = require('./Axis.js');
let SetElevatorResult = require('./SetElevatorResult.js');
let SetElevatorAction = require('./SetElevatorAction.js');
let SetElevatorActionResult = require('./SetElevatorActionResult.js');
let SetElevatorGoal = require('./SetElevatorGoal.js');
let SetElevatorFeedback = require('./SetElevatorFeedback.js');
let SetElevatorActionFeedback = require('./SetElevatorActionFeedback.js');
let SetElevatorActionGoal = require('./SetElevatorActionGoal.js');

module.exports = {
  QueryAlarm: QueryAlarm,
  Registers: Registers,
  ElevatorStatus: ElevatorStatus,
  Interfaces: Interfaces,
  SubState: SubState,
  ElevatorAction: ElevatorAction,
  MotorsStatusDifferential: MotorsStatusDifferential,
  encoders: encoders,
  MotorHeadingOffset: MotorHeadingOffset,
  Pose2DStamped: Pose2DStamped,
  inputs_outputs: inputs_outputs,
  Data: Data,
  Register: Register,
  BatteryStatus: BatteryStatus,
  AlarmSensor: AlarmSensor,
  RobotnikMotorsStatus: RobotnikMotorsStatus,
  StringArray: StringArray,
  BatteryDockingStatus: BatteryDockingStatus,
  named_inputs_outputs: named_inputs_outputs,
  BatteryDockingStatusStamped: BatteryDockingStatusStamped,
  LaserStatus: LaserStatus,
  LaserMode: LaserMode,
  Pose2DArray: Pose2DArray,
  InverterStatus: InverterStatus,
  MotorPID: MotorPID,
  alarmsmonitor: alarmsmonitor,
  alarmmonitor: alarmmonitor,
  BatteryStatusStamped: BatteryStatusStamped,
  Cartesian_Euler_pose: Cartesian_Euler_pose,
  MotorStatus: MotorStatus,
  ptz: ptz,
  Alarms: Alarms,
  State: State,
  BoolArray: BoolArray,
  SafetyModuleStatus: SafetyModuleStatus,
  named_input_output: named_input_output,
  MotorsStatus: MotorsStatus,
  Axis: Axis,
  SetElevatorResult: SetElevatorResult,
  SetElevatorAction: SetElevatorAction,
  SetElevatorActionResult: SetElevatorActionResult,
  SetElevatorGoal: SetElevatorGoal,
  SetElevatorFeedback: SetElevatorFeedback,
  SetElevatorActionFeedback: SetElevatorActionFeedback,
  SetElevatorActionGoal: SetElevatorActionGoal,
};
